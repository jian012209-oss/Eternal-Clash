namespace EternalClash
{
    // Familiar MOBA shop navigation, with original Eternal Clash items and UI art.
    public enum ShopCategory
    {
        Recommended, Attack, Magic, Defense, Boots, Jungle, Roaming
    }
}
