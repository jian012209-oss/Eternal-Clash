using UnityEngine;
using System.Collections.Generic;
using System.Linq;

namespace EternalClash
{
    [CreateAssetMenu(menuName = "Eternal Clash/Shop Catalog")]
    public class ShopCatalog : ScriptableObject
    {
        public List<EquipmentDefinition> allItems = new List<EquipmentDefinition>();

        public List<EquipmentDefinition> GetRecommendedItems() => allItems.Where(i => i != null && i.recommended).ToList();

        public List<EquipmentDefinition> GetItems(ShopCategory category)
        {
            return allItems.Where(i => i != null && i.category == category).ToList();
        }
    }
}
