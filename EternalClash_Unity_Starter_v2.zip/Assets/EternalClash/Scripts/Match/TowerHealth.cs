using UnityEngine;

namespace EternalClash
{
    public class TowerHealth : MonoBehaviour
    {
        public Team team;
        public float maxHealth = 5000;
        public float attackRange = 8;
        public float attackDamage = 180;
        public float attackInterval = 1;
        float health, attackTimer;
        void Awake() { health = maxHealth; }
        void Update() { attackTimer = Mathf.Max(0, attackTimer - Time.deltaTime); }
        public bool CanAttack(Team targetTeam, float distance) =>
            targetTeam != team && targetTeam != Team.Neutral && distance <= attackRange && attackTimer <= 0;
        public void NotifyAttack() { attackTimer = attackInterval; }
        public void TakeDamage(float amount)
        {
            health = Mathf.Max(0, health - Mathf.Max(0, amount));
            if (health <= 0) Destroy(gameObject);
        }
    }
}
