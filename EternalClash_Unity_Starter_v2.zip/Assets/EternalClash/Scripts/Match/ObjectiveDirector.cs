using UnityEngine;

namespace EternalClash
{
    public class ObjectiveDirector : MonoBehaviour
    {
        [Header("Original objectives")]
        public NeutralMonster riverWarden;     // Turtle-like early team objective
        public NeutralMonster worldColossus;   // Lord-like late siege objective
        public float riverWardenFirstSpawn = 120f;
        public float worldColossusFirstSpawn = 600f;
        float elapsed;
        bool riverAnnounced, colossusAnnounced;

        void Update()
        {
            elapsed += Time.deltaTime;
            if (!riverAnnounced && elapsed >= riverWardenFirstSpawn)
            { riverAnnounced = true; if (riverWarden) riverWarden.gameObject.SetActive(true); }
            if (!colossusAnnounced && elapsed >= worldColossusFirstSpawn)
            { colossusAnnounced = true; if (worldColossus) worldColossus.gameObject.SetActive(true); }
        }
    }
}
