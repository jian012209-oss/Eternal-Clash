using UnityEngine;
using UnityEngine.AI;

namespace EternalClash
{
    public enum MinionClass { Vanguard, Ranger, SiegeBeast }
    public class MinionUnit : MonoBehaviour
    {
        public Team team;
        public MinionClass minionClass;
        public float health = 650;
        public float damage = 55;
        public float attackRange = 2;
        public float attackRate = 1.2f;
        public float bounty = 35;
        float timer;
        NavMeshAgent agent;
        public Transform currentTarget;
        void Awake() { agent = GetComponent<NavMeshAgent>(); }
        void Update()
        {
            timer -= Time.deltaTime;
            if (currentTarget && agent)
            {
                float d = Vector3.Distance(transform.position, currentTarget.position);
                agent.isStopped = d <= attackRange;
                if (!agent.isStopped) agent.SetDestination(currentTarget.position);
                else if (timer <= 0) { timer = attackRate; /* call target damage interface */ }
            }
        }
        public void TakeDamage(float value)
        {
            health -= Mathf.Max(0, value);
            if (health <= 0) Destroy(gameObject);
        }
    }
}
