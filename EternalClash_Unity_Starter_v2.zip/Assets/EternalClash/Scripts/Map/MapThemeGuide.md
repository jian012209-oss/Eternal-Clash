# Eternal Clash battlefield art direction

Create an original three-lane symmetrical battlefield with the same broad MOBA readability conventions:
- Azure and Crimson bases at opposite corners.
- Top, middle and bottom lanes with three defensive structures per lane.
- River crossing the middle with brush/grass concealment zones.
- Mirrored jungle camps and alternate flank routes.
- Central river objective site for the **River Warden**.
- Late-game siege objective pit for the **World Colossus**.
- Base Core protected by the final high-ground tower.

Do not trace or reuse MLBB's minimap, map geometry, icons, textures, or UI artwork. Use original layout, landmarks, color language and names.
