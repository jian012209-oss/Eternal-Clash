using UnityEngine;

namespace EternalClash
{
    public enum NeutralObjective { SmallCamp, AncientGuardian, RiverWarden, WorldColossus }
    public class NeutralMonster : MonoBehaviour
    {
        public NeutralObjective objectiveType;
        public float maxHealth = 1800;
        public int goldReward = 80;
        public int experienceReward = 60;
        public float respawnSeconds = 90;
        float health;
        void Awake() { health = maxHealth; }
        public void TakeTrueDamage(float damage)
        {
            health -= Mathf.Max(0, damage);
            if (health <= 0) Defeated();
        }
        void Defeated()
        {
            // Connect rewards, team buffs, announcement and timed respawn in ObjectiveDirector.
            gameObject.SetActive(false);
        }
    }
}
