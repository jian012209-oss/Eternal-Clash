using UnityEngine;

namespace EternalClash
{
    public enum BattleSpellType
    {
        Sprint, Flicker, Purify, Aegis, Heal, Execute, Flameshot,
        Arrival, Conceal, Retribution
    }

    [CreateAssetMenu(menuName = "Eternal Clash/Battle Spell")]
    public class BattleSpellDefinition : ScriptableObject
    {
        public BattleSpellType spellType;
        public string spellName;
        [TextArea] public string description;
        public float cooldown = 90;
        public float effectDuration = 2;
        public float magnitude = 1;
        public GameObject effectPrefab;
        public AudioClip activationAudio;
    }
}
