using UnityEngine;

namespace EternalClash
{
    public class BattleSpellCaster : MonoBehaviour
    {
        public BattleSpellDefinition selectedSpell;
        float cooldownLeft;
        public bool Ready => selectedSpell && cooldownLeft <= 0;

        void Update() { cooldownLeft = Mathf.Max(0, cooldownLeft - Time.deltaTime); }

        public bool Activate(Vector3 aimPoint)
        {
            if (!Ready) return false;
            cooldownLeft = selectedSpell.cooldown;
            if (selectedSpell.effectPrefab)
                Instantiate(selectedSpell.effectPrefab, transform.position, Quaternion.identity);
            if (selectedSpell.activationAudio)
                AudioSource.PlayClipAtPoint(selectedSpell.activationAudio, transform.position);

            switch (selectedSpell.spellType)
            {
                case BattleSpellType.Sprint:
                    var body = GetComponent<Rigidbody>();
                    if (body) body.AddForce(transform.forward * 8f, ForceMode.VelocityChange);
                    break;
                case BattleSpellType.Flicker:
                    Vector3 destination = aimPoint;
                    if (Vector3.Distance(transform.position, destination) > 7f)
                        destination = transform.position + (destination - transform.position).normalized * 7f;
                    transform.position = destination;
                    break;
                case BattleSpellType.Retribution:
                    // Server-authoritative monster damage must be implemented for online matches.
                    var monster = Physics.OverlapSphere(transform.position, 5f)
                        .SelectComponent<NeutralMonster>();
                    if (monster) monster.TakeTrueDamage(600);
                    break;
            }
            return true;
        }
    }

    static class ColliderSearch
    {
        public static T SelectComponent<T>(this Collider[] colliders) where T : Component
        {
            foreach (var c in colliders) { var found = c.GetComponent<T>(); if (found) return found; }
            return null;
        }
    }
}
