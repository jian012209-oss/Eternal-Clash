using UnityEngine;

namespace EternalClash
{
    public class PlayerProgression : MonoBehaviour
    {
        public int Level { get; private set; } = MatchRules.StartingLevel;
        public int Gold { get; private set; } = MatchRules.StartingGold;
        public int Experience { get; private set; }

        public void AddGold(int amount) { Gold += Mathf.Max(0, amount); }
        public void AddExperience(int amount)
        {
            Experience += Mathf.Max(0, amount);
            while (Level < MatchRules.MaxHeroLevel && Experience >= RequiredXp(Level))
            { Experience -= RequiredXp(Level); Level++; }
        }
        int RequiredXp(int level) => 100 + level * 45;
        public bool SpendGold(int amount)
        {
            if (amount < 0 || Gold < amount) return false;
            Gold -= amount; return true;
        }
    }
}
