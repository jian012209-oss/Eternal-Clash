namespace EternalClash
{
    public enum RankTier { Bronze, Silver, Gold, Platinum, Diamond, Master, Grandmaster, Challenger, Legend }
    public static class RankedProgress
    {
        public static int StarsPerDivision(RankTier tier) =>
            tier <= RankTier.Platinum ? 3 : tier == RankTier.Legend ? int.MaxValue : 5;

        // A division is represented by an integer: 0=III, 1=II, 2=I.
        public static void ApplyResult(ref RankTier tier, ref int division, ref int stars, bool won)
        {
            stars += won ? 1 : -1;
            if (tier == RankTier.Legend) { if (stars < 0) stars = 0; return; }
            int needed = StarsPerDivision(tier);
            if (stars >= needed)
            {
                stars -= needed;
                if (division < 2) division++;
                else if (tier < RankTier.Legend) { tier++; division = 0; }
            }
            else if (stars < 0)
            {
                stars = 0;
                if (division > 0) division--;
                else if (tier > RankTier.Bronze) { tier--; division = 2; }
            }
        }
    }
}
