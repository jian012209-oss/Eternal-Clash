using UnityEngine;

namespace EternalClash
{
    [CreateAssetMenu(menuName = "Eternal Clash/Hero Definition")]
    public class HeroDefinition : ScriptableObject
    {
        public string heroId;
        public string displayName;
        public HeroRole role;
        [TextArea] public string lore;
        public GameObject characterPrefab;
        public RuntimeAnimatorController animator;
        public Sprite portrait;
        [Header("Base attributes")]
        public float maxHealth = 2800;
        public float attackDamage = 120;
        public float abilityPower = 100;
        public float armor = 25;
        public float magicResistance = 20;
        public float moveSpeed = 5.2f;
        public SkillDefinition passive;
        public SkillDefinition skillOne;
        public SkillDefinition skillTwo;
        public SkillDefinition ultimate;
    }
}
