using UnityEngine;

namespace EternalClash
{
    public enum SkillTargeting { Self, Direction, GroundPoint, UnitTarget, Area }
    [CreateAssetMenu(menuName = "Eternal Clash/Skill Definition")]
    public class SkillDefinition : ScriptableObject
    {
        public string skillName;
        [TextArea] public string description;
        public SkillTargeting targeting;
        public float cooldown = 8;
        public float resourceCost = 30;
        public float castRange = 6;
        public float radius = 2;
        public float baseDamage = 150;
        public float scaling = 0.8f;
        public GameObject castVfx;
        public GameObject projectilePrefab;
        public GameObject impactVfx;
        public AnimationClip castAnimation;
        public AudioClip castAudio;
        public bool appliesCrowdControl;
        public float crowdControlSeconds;
    }
}
