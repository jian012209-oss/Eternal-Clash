using UnityEngine;

namespace EternalClash
{
    public class LaneSpawner : MonoBehaviour
    {
        public GameObject azureMinionPrefab, crimsonMinionPrefab;
        public Transform[] azureLaneStarts, crimsonLaneStarts;
        public float waveInterval = MatchRules.MinionWaveSeconds;
        float timer;

        void Update()
        {
            if (azureMinionPrefab == null || crimsonMinionPrefab == null) return;
            timer += Time.deltaTime;
            if (timer >= waveInterval) { timer = 0; SpawnWave(); }
        }
        void SpawnWave()
        {
            for (int lane = 0; lane < 3; lane++)
            {
                if (azureLaneStarts != null && lane < azureLaneStarts.Length && azureLaneStarts[lane])
                    Instantiate(azureMinionPrefab, azureLaneStarts[lane].position, azureLaneStarts[lane].rotation);
                if (crimsonLaneStarts != null && lane < crimsonLaneStarts.Length && crimsonLaneStarts[lane])
                    Instantiate(crimsonMinionPrefab, crimsonLaneStarts[lane].position, crimsonLaneStarts[lane].rotation);
            }
        }
    }
}
