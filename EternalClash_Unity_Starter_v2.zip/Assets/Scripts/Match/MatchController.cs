using UnityEngine;

namespace EternalClash
{
    public class MatchController : MonoBehaviour
    {
        public MatchState State { get; private set; } = MatchState.Loading;
        public float matchTime { get; private set; }
        public int azureCoreHealth = 10000;
        public int crimsonCoreHealth = 10000;

        public void StartMatch() { matchTime = 0; State = MatchState.Playing; }
        void Update() { if (State == MatchState.Playing) matchTime += Time.deltaTime; }

        public void DamageCore(Team attackingTeam, int damage)
        {
            if (State != MatchState.Playing) return;
            if (attackingTeam == Team.Azure) crimsonCoreHealth = Mathf.Max(0, crimsonCoreHealth - damage);
            if (attackingTeam == Team.Crimson) azureCoreHealth = Mathf.Max(0, azureCoreHealth - damage);
            if (azureCoreHealth == 0 || crimsonCoreHealth == 0) State = MatchState.Finished;
        }
    }
}
