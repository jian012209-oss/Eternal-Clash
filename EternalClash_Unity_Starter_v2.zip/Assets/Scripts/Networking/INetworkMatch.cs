namespace EternalClash
{
    // Implement with a production networking stack (e.g. Netcode for GameObjects,
    // Photon Fusion, or a dedicated authoritative server). Never trust client damage.
    public interface INetworkMatch
    {
        void SendSkillCast(string heroId, int skillSlot, float x, float y, float z);
        void SendPurchase(string itemId);
        void SendMatchResult(string resultToken);
    }
}
