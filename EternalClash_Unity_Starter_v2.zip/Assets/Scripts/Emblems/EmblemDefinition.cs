using UnityEngine;

namespace EternalClash
{
    public enum EmblemFamily { Warrior, Assassin, Mage, Marksman, Tank, Support }
    [CreateAssetMenu(menuName = "Eternal Clash/Emblem")]
    public class EmblemDefinition : ScriptableObject
    {
        public EmblemFamily family;
        public int level = 1;
        public float health, attack, abilityPower, armor, magicResistance, attackSpeed,
                     movementSpeed, cooldownReduction;
        [TextArea] public string talentOne, talentTwo, talentThree;
    }
}
