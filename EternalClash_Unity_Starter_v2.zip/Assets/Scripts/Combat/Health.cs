using UnityEngine;
using System;

namespace EternalClash
{
    public class Health : MonoBehaviour
    {
        public float maxHealth = 2800;
        public float Current { get; private set; }
        public bool IsAlive => Current > 0;
        public event Action Died;
        void Awake() { Current = maxHealth; }

        public void ApplyDamage(float amount)
        {
            if (!IsAlive) return;
            Current = Mathf.Max(0, Current - Mathf.Max(0, amount));
            if (Current <= 0) Died?.Invoke();
        }
        public void Heal(float amount) { if (IsAlive) Current = Mathf.Min(maxHealth, Current + amount); }
        public void Respawn() { Current = maxHealth; }
    }
}
