using UnityEngine;
using System.Collections;

namespace EternalClash
{
    public class SkillCaster : MonoBehaviour
    {
        public HeroDefinition hero;
        public Transform castPoint;
        public Animator animator;
        float[] cooldowns = new float[3];

        void Update()
        {
            for (int i = 0; i < cooldowns.Length; i++)
                cooldowns[i] = Mathf.Max(0, cooldowns[i] - Time.deltaTime);
        }

        public bool Cast(int slot, Vector3 aimPoint)
        {
            if (hero == null || slot < 0 || slot > 2 || cooldowns[slot] > 0) return false;
            SkillDefinition skill = slot == 0 ? hero.skillOne :
                                    slot == 1 ? hero.skillTwo : hero.ultimate;
            if (skill == null) return false;

            cooldowns[slot] = skill.cooldown;
            if (animator) animator.SetTrigger("Cast" + (slot + 1));
            if (skill.castVfx) Instantiate(skill.castVfx, castPoint.position, castPoint.rotation);
            if (skill.castAudio) AudioSource.PlayClipAtPoint(skill.castAudio, transform.position);

            if (skill.projectilePrefab)
            {
                Vector3 direction = (aimPoint - castPoint.position).normalized;
                var projectile = Instantiate(skill.projectilePrefab, castPoint.position,
                    Quaternion.LookRotation(direction));
                var body = projectile.GetComponent<Rigidbody>();
                if (body) body.velocity = direction * 18f;
            }
            if (skill.targeting == SkillTargeting.GroundPoint && skill.impactVfx)
                Instantiate(skill.impactVfx, aimPoint, Quaternion.identity);

            // Damage, hit validation and status effects should be resolved by the server online.
            return true;
        }
    }
}
