namespace EternalClash
{
    public static class MatchRules
    {
        public const int TeamSize = 5;
        public const int LaneCount = 3;
        public const int MaxHeroLevel = 15;
        public const float MinionWaveSeconds = 30f;
        public const float RespawnBaseSeconds = 8f;
        public const int StartingGold = 500;
        public const int StartingLevel = 1;
        public const int MaxInventorySlots = 6;
        public const int SkillsPerHero = 4; // passive + three active skills
    }

    public enum Team { Azure, Crimson, Neutral }
    public enum Lane { Top, Mid, Bottom }
    public enum HeroRole { Fighter, Tank, Assassin, Mage, Marksman, Support }
    public enum MatchState { Loading, Countdown, Playing, Finished }
}
