using UnityEngine;
using System.Collections.Generic;

namespace EternalClash
{
    public class Inventory : MonoBehaviour
    {
        public List<EquipmentDefinition> items = new List<EquipmentDefinition>(6);
        public bool TryBuy(EquipmentDefinition item, PlayerProgression wallet)
        {
            if (!item || items.Count >= MatchRules.MaxInventorySlots || !wallet.SpendGold(item.cost))
                return false;
            items.Add(item); return true;
        }
    }
}
