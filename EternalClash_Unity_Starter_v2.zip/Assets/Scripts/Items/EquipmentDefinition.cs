using UnityEngine;

namespace EternalClash
{
    [CreateAssetMenu(menuName = "Eternal Clash/Equipment")]
    public class EquipmentDefinition : ScriptableObject
    {
        public string itemId, itemName;
        [TextArea] public string description;
        public int cost = 900;
        public float bonusHealth, bonusAttack, bonusAbilityPower, bonusArmor,
                     bonusMagicResistance, bonusAttackSpeed, bonusMoveSpeed,
                     cooldownReduction, lifesteal;
        public EquipmentDefinition upgradesInto;
        public Sprite icon;
    }
}
