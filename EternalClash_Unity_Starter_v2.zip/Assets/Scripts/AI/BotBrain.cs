using UnityEngine;
using UnityEngine.AI;

namespace EternalClash
{
    [RequireComponent(typeof(NavMeshAgent))]
    public class BotBrain : MonoBehaviour
    {
        public Transform laneWaypoint;
        public Transform target;
        public float engageRange = 5;
        NavMeshAgent agent;
        void Awake() { agent = GetComponent<NavMeshAgent>(); }
        void Update()
        {
            if (target && Vector3.Distance(transform.position, target.position) <= engageRange)
            {
                agent.isStopped = true;
                transform.LookAt(new Vector3(target.position.x, transform.position.y, target.position.z));
                // Hook attack/skill decisions here; use difficulty profiles for bot skill.
            }
            else
            {
                agent.isStopped = false;
                if (laneWaypoint) agent.SetDestination(laneWaypoint.position);
            }
        }
    }
}
