using UnityEngine;
using UnityEngine.EventSystems;

namespace EternalClash
{
    public class TouchSkillButton : MonoBehaviour, IPointerDownHandler
    {
        public SkillCaster caster;
        public int skillSlot;
        public Transform aimTarget;
        public void OnPointerDown(PointerEventData eventData)
        {
            if (caster && aimTarget) caster.Cast(skillSlot, aimTarget.position);
        }
    }
}
