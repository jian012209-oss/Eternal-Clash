# ETERNAL CLASH — Unity Android Starter

Unity project foundation for an original 5v5 MOBA. Recommended: Unity 2022.3 LTS or newer, URP, Android Build Support.

## Included
- 5v5 match rules: three lanes, minions, towers, base core, jungle camps, river objectives, levels, gold, respawn.
- Hero data model with 120 configurable roster slots.
- Passive + three active skills per hero.
- Skill VFX hooks for realistic particles, trails, impact decals, camera shake and animation events.
- Equipment, six emblem families, offline bot decision-making, ranked progression.
- Touch joystick/skill button input hooks.
- Online networking adapter interface. A real authoritative server and matchmaking service must be deployed separately.

## Install
1. Create a new Unity 3D (URP) project.
2. Copy the `Assets` folder into the Unity project.
3. In Unity, create a scene and add `MatchController`, `LaneSpawner`, and `ObjectiveDirector` components to suitable GameObjects.
4. Create hero/item/emblem assets using the ScriptableObject menu entries.
5. Add your original character models, rigged animations, materials, and VFX prefabs.
6. Switch Build Settings to Android.

This is a playable-systems foundation, not a finished commercial game. The generated roster poster is a visual reference; each hero still needs an individual model, rig, textures, animation set, and skill VFX.
